#ifndef _ALPHANUMERICDISPLAYTBA_H
#define _ALPHANUMERICDISPLAYTBA_H

#include "Arduino.h"


#define DS 8
#define STCP 9
#define SHCP 10
#define REGISTER_SIZE 16

class AlphaDisplay{
	
	private:

		uint16_t  characters[128];
		uint8_t _dspin = DS;
		uint8_t _stcp = STCP;
		uint8_t _shcp = SHCP;


	public:

        AlphaDisplay(){

        }

        void setPins(uint8_t ds, uint8_t stcp, uint8_t shcp){
            this->_dspin = ds;
            this->_stcp = stcp;
            this->_shcp = shcp;
        }
	
		void init(){
			uint16_t  digits[10] = {
				0xEADA,
				0xBF7F,
				0xF2F2,
				0xF6D2,
				0xE7D3,
				0xE6D6,
				0xE2D6,
				0xFFDA,
				0xE2D2,
				0xE7D2
				};
			uint16_t upper[26] = {
				0xE3D2,
				0xBE52,
				0xEAFE,
				0xBE5A,
				0xE2F6,
				0xE3F6,
				0xEAD6,
				0xE3D3,
				0xBF7F,
				0xFADB,
				0xE3BD,
				0xEAFF,
				0xCBD9,
				0xCB9B,
				0xEADA,
				0xE3F2,
				0xEA9A,
				0xE3B2,
				0xE6D6,
				0xBF7E,
				0xEADB,
				0xE9FD,
				0xE99B,
				0xDDBD,
				0xE6D3,
				0xFCFC
			};

			//null character
            this->characters[0] = 0xffff;

            //space character
            this->characters[32] = 0xffff;

            //populate digits
            for (int i = 0; i < 10; ++i) {
                this->characters[i+48] = digits[i];
            }

            //populate upper digits
            for (int i = 0; i < 26; ++i) {
                this->characters[i+65] = upper[i];
            }

            pinMode(this->_dspin, OUTPUT);
            pinMode(this->_stcp, OUTPUT);
            pinMode(this->_shcp, OUTPUT);
            delay(100);

		};

        uint16_t charVal(uint8_t i){
            return this->characters[i];
        }

        void updateDisplay(char c){
            uint8_t  index =  uint8_t(c);
            uint16_t value = 0xffff;

            if (index < 128 && index >= 0){
                value = this->characters[index];
            }

            bool out = true;

            for (uint8_t i ; i < REGISTER_SIZE; i++ ){

                digitalWrite(this->_shcp, LOW);
                digitalWrite(this->_stcp, LOW);
                digitalWrite(this->_dspin, ((value & (1<< i)) >= 1));
                digitalWrite(this->_stcp, HIGH);
                digitalWrite(this->_shcp, HIGH);


            }




        }

};

#endif